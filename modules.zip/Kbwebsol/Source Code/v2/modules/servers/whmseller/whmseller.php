<?php
	function whmseller_ConfigOptions() {
		$configarray = array(					"Package Name" => array( "Type" => "text", "Size" => "30", "Description" => "Package Name on server" ),
			"No of Domains" => array( "Type" => "text", "Size" => "4", "Description" => "Max number of Domains" ),
			"Disk Space" => array( "Type" => "text", "Size" => "8", "Description" => "MB" ),
			"Bandwidth" => array( "Type" => "text", "Size" => "8", "Description" => "MB" ),
			"Diskspace Overselling" => array( "Type" => "yesno", "Description" => "Tick to enable" ),
			"Bandwidth Overselling" => array( "Type" => "yesno", "Description" => "Tick to enable" ),
			"Account to Create" => array( "Type" => "radio", "Options" => "Reseller,Master,Alpha", "Default" => "Reseller", "Description" => "Select the type of account you want to create" ),
			"No of Resellers" => array( "Type" => "text", "Size" => "4", "Description" => "Max number of Resellers(Only for creating Master Account)" ),
			"Max Masters" => array( "Type" => "text", "Size" => "4", "Description" => "Max number of Masters" ),
		);
		return $configarray ;
	}
	
	function whmseller_CreateAccount($params) {			//error_log("package 5 : ".$params["configoption7"], 3, "alpha_whmcs1.log");	
		$whmArray = array();
		if ($params["configoption7"]=="Alpha")
		{			
		$whmArray["action"] = "createalpha";
		}		
		if ($params["configoption7"]=="Master") 
		{
			$whmArray["action"] = "createmaster";
		}
		if ($params["configoption7"]=="Reseller") 		{
		$whmArray["action"] = "createreseller";
		}		
		$whmArray["domain"] = $params["domain"];
		$whmArray["username"] = $params["username"];
		$whmArray["password"] = $params["password"];
		$whmArray["package"] = $params["configoption1"];						
		$whmArray["domainsallowed"] = $params["configoption2"];
		$whmArray["resellersallowed"] = $params["configoption8"];	
		$whmArray["maxmasters"] = $params["configoption9"];		
		$whmArray["email"] = $params["clientsdetails"]["email"];				
		$whmArray["diskspace"] = $params["configoption3"];
		$whmArray["bandwidth"] = $params["configoption4"];
		$whmArray["dsoversell"] = $params["configoption5"];
		$whmArray["bwoversell"] = $params["configoption6"];
		if($params["configoption7"]=="Alpha") {	
		$result = whmsellerApi2($whmArray, $params);	
		}		else
			$result = whmsellerApi($whmArray, $params);
		if($result["error"] != "") 
			return $result["error"];
		else
			return "success";
	}
	
	function whmseller_SuspendAccount($params) {
		$whmArray = array();
		if($params["configoption6"]=="Master") {
			$whmArray["action"] = "suspendmaster";
		}
		else {
			$whmArray["action"] = "suspendreseller";
		}
		$whmArray["username"] = $params["username"];
		$result = whmsellerApi($whmArray, $params);
		if($result["error"]) {
			return $result["error"];
		}
		return "success";
	}
	
	function whmseller_UnsuspendAccount($params) {
		$whmArray = array();
		if($params["configoption6"]=="Master") {
			$whmArray["action"] = "unsuspendmaster";
		}
		else {
			$whmArray["action"] = "unsuspendreseller";
		}
		$whmArray["username"] = $params["username"];
		$result = whmsellerApi($whmArray, $params);
		if($result["error"]) {
			return $result["error"];
		}
		return "success";
	}
	
	function whmseller_TerminateAccount($params) {
		$whmArray = array();
		if($params["configoption7"]=="Master") {
			$whmArray["action"] = "terminatemaster";
		}
		if($params["configoption7"]=="Reseller") {
			$whmArray["action"] = "terminatereseller";
		}				if($params["configoption7"]=="Alpha") {			$whmArray["action"] = "terminatealpha";		}
		$whmArray["username"] = $params["username"];
		$result = whmsellerApi($whmArray, $params);
		if($result["error"]) {
			return $result["error"];
		}
		return "success";
	}
	
	function whmseller_ChangePassword($params) {
		$whmArray = array();
		$whmArray["action"] = "changepwd";
		$whmArray["username"] = $params["username"];
		$whmArray["password"] = $params["password"];
		$result = whmAPI($whmArray, $params);
		if($result["error"]) {
			return $result["error"];
		}
		return "success";
	}
	
	function whmsellerApi($request, $params) {
		$request = http_build_query($request);
		$query = "https://".$params['serverip'].":2087/cgi/whmseller/sellercp/index.cgi?modules=api&".$request;
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
		if($params['serverpassword'] != "") {
			$header[0] = "Authorization: Basic ". base64_encode ($params['serverusername'] . ":" . $params['serverpassword']);
		}
		else {
			$header[0] = "Authorization: WHM ".$params['serverusername'].":" . preg_replace("'(\r|\n)'","",$params['serveraccesshash']);
		}
		curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
		curl_setopt($curl, CURLOPT_URL, $query);

		
		$result = curl_exec($curl);
	
		curl_close($curl);
	
	
		return json_decode($result,true);
	}
	function whmsellerApi2($request, $params)
	 {	
	 $request = http_build_query($request);
	
	 $query = "https://".$params['serverip'].":2087/cgi/whmseller/sellercp/index.cgi?modules=api&".$request;	
	 $curl = curl_init();
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
	if($params['serverpassword'] != "")
	 { $header[0] = "Authorization: Basic ". base64_encode ($params['serverusername'] . ":" . $params['serverpassword']);
	 	}	
	 	else {	
	 $header[0] = "Authorization: WHM ".$params['serverusername'].":" . preg_replace("'(\r|\n)'","",$params['serveraccesshash']);
	 		}	
	 curl_setopt($curl,CURLOPT_HTTPHEADER,$header);	
	 curl_setopt($curl, CURLOPT_URL, $query);	
	 $result = curl_exec($curl);

		
	 curl_close($curl);	

	 return json_decode($result,true);	}