<?php 
require("/home/resellercenter/public_html/init.php");
require_once("/home/resellercenter/public_html/vendor/autoload.php");

use WHMCS\Database\Capsule;
$ip= $_SERVER['REMOTE_ADDR'];

$new = Capsule::table('tblhosting')
->join('tblproducts','tblhosting.packageid','=', 'tblproducts.id')
->join('mod_licensing','tblhosting.id','=','mod_licensing.serviceid')
->select('tblhosting.regdate','tblhosting.nextduedate','tblproducts.configoption1','mod_licensing.validip','mod_licensing.status')
->where('tblproducts.configoption1','=','1')
->where('mod_licensing.validip','=',$ip)
->where('mod_licensing.status','=','Active')
->get();
foreach($new as $row){

$r_date= $row->nextduedate;

echo $r_date;

}


?>
